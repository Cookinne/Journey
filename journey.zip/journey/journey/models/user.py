#!/usr/bin/env python
# encoding: utf-8

# 引入Form基类
from flask_wtf import FlaskForm
# 引入Form元素父类
from wtforms import IntegerField, StringField, PasswordField
# 引入Form验证父类
from wtforms.validators import DataRequired, Length


class User(FlaskForm):
    """
    用户model
    """

    # ID
    id = IntegerField()

    # 用户名
    name = StringField('name', validators=[DataRequired(message=u"用户名不能为空"),\
                                           Length(4, 20, message=u'用户名长度位于4~25之间')], render_kw={'placeholder': u'用户名'})
    # 密码
    password = PasswordField('password', validators=[DataRequired(message=u"密码不能为空"), \
                                           Length(6, 20, message=u'密码长度位于6~25之间')], render_kw={'placeholder': u'密码'})
