#!/usr/bin/env python
# encoding: utf-8

# 引入Form基类
from flask_wtf import FlaskForm
# 引入Form元素父类
from wtforms import IntegerField, StringField, DateTimeField


class Invitation(FlaskForm):
    """
    帖子model
    """

    # ID
    id = IntegerField()

    # 标题
    title = StringField()
    # 内容
    content = StringField()
    # 创建时间
    create_time = DateTimeField()
    # 创建人
    creator_id = IntegerField()
