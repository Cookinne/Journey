#!/usr/bin/env python
# encoding: utf-8
import functools

from flask import session, redirect, url_for, g, flash

from model.account_model.admin import Admin


def login_required(method):
    """
    验证登陆用户才能访问服务接口
    :param method:
    """

    @functools.wraps(method)
    def wrapper(*args, **kwargs):
        user_id = session.get('user_id')
        current_user = User.get(user_id)
        if not current_admin or current_admin.is_freeze:
            flash("登陆已过期，请重新登陆", category="error")
            return redirect(url_for("login"))

        g.current_admin = current_admin
        return method(*args, **kwargs)

    return wrapper


def check_role(method):
    """
    验证登陆用户才能访问服务接口
    :param method:
    """

    @functools.wraps(method)
    def wrapper(*args, **kwargs):
        admin_id = session.get('admin_id')
        current_admin = Admin.get(admin_id)
        if current_admin.role != "admin":
            flash("没有该权限", category="error")
            return redirect(url_for("index"))

        g.current_admin = current_admin
        return method(*args, **kwargs)

    return wrapper
