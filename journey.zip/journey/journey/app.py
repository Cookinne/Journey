#!/usr/bin/env python
# encoding: utf-8

from flask import Flask, request, flash, redirect, url_for, render_template, g, Response, jsonify
import json
from models.user import User
from core.db.userHandle import UserHandle
from core.db.InvHandle import InvHandle
from models.invitation import Invitation
import time
import datetime

app = Flask(__name__)
app.config["SECRET_KEY"] = "12345678"


@app.before_request
def before_request():
    g.user_id = ""


@app.route('/')
def begin():
    return render_template("login.html", form={})


@app.route('/index', methods=['GET'])
def index():
    # 获取帖子
    size = 5
    current_page = request.args.get('current_page')
    print('current_page', current_page)
    page = 0 if current_page is None else int(current_page)
    handle = InvHandle()
    total, db_data = handle.inv_list({
        'size': size,
        'page': page
    })
    page_count = total / size
    if total % size:
        page_count += 1
    print('db_data', db_data)
    user_id = request.args.get('user_id')
    print('index页面，user_id', user_id)
    print('page_count', page_count)
    minutes10_before = (datetime.datetime.now() - datetime.timedelta(minutes=10)).strftime("%Y-%m-%d %H:%M:%S")
    # 转化为数组
    time_array = time.strptime(minutes10_before, "%Y-%m-%d %H:%M:%S")
    # 转换为时间戳
    time_stamp = int(time.mktime(time_array))  # 1524822540

    if current_page is not None:
        response = json.dumps({'db_data': db_data, 'page': page, 'time_stamp': time_stamp})
        return Response(response, mimetype='application/json')
    return render_template("index.html", user_id=user_id, total=total, \
                               db_data=db_data, page=page, page_count=page_count, time_stamp=time_stamp, time=time)


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == "GET":
        form = User()
        return render_template("login.html", form=form)
    else:
        form = User(formdata=request.data)
        data = {
            'name': request.form.get('name'),
            'password': request.form.get('password'),
        }
        print('name', request.form.get('name'))
        handle = UserHandle()
        back_data = handle.get_user(data)
        if back_data['success']:
            flash(back_data['message'], category='message')
            g.user_id = back_data['data'][0]  # 设置无效 因为下面重定向了。
            return redirect(url_for('index', user_id=back_data['data'][0]))
        else:
            flash(back_data['message'], category='message')
            return render_template("login.html", form=form)


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == "GET":
        form = User()
        return render_template("register.html", form=form)
    else:
        form = User(formdata=request.data)
        data = {
            'name': request.form.get('name'),
            'password': request.form.get('password'),
        }
        handle = UserHandle()
        handle.user_add(data)

        flash("注册成功", category='message')
        response = json.dumps({'success': True})
        return Response(response, mimetype='application/json')


@app.route('/inv_add', methods=['GET', 'POST'])
def inv_add():
    user_id = request.args.get('user_id')
    print('user_id', user_id)
    if request.method == "GET":
        form = Invitation()
        return render_template("inv_add.html", user_id=user_id)
    else:
        title = request.form.get('title')
        content = request.form.get('content')
        create_time = time.time()
        data = {
            'creator_id': user_id,
            'title': title,
            'content': content,
            'create_time': create_time
        }
        print('data', data);
        handle = InvHandle()
        handle.inv_add(data)
        print('create_time', create_time)
        return redirect(url_for('index', user_id=user_id))


@app.route('/inv_detail', methods=['GET'])
def inv_detail():
    user_id = request.args.get('user_id')
    user_id = int(user_id)
    inv_id = request.args.get('inv_id')
    print('user_id', user_id)
    handle = InvHandle()
    data = handle.inv_detail({
        'inv_id': inv_id
    })
    print('data', data)
    return render_template("inv_detail.html", user_id=user_id, data=data, inv_id=inv_id, time=time)


@app.route('/inv_delete', methods=['POST'])
def inv_delete():
    user_id = request.form.get('user_id')
    user_id = int(user_id)
    inv_id = request.form.get('inv_id')
    inv_id = int(inv_id)
    handle = InvHandle()
    result = handle.inv_delete({
        'inv_id': inv_id,
        'user_id': user_id
    })
    print('result', result)
    response = json.dumps({'success': True})
    return Response(response, mimetype='application/json')


@app.route('/reset_password', methods=['GET', 'POST'])
def reset_password():
    if request.method == "GET":
        form = User()
        user_id = request.args.get('user_id')
        user_id = int(user_id)
        return render_template("reset_password.html", form=form, user_id=user_id)
    else:
        user_id = request.form.get('user_id')
        user_id = int(user_id)
        form = User(formdata=request.data)
        data = {
            'password': request.form.get('password'),
            'user_id': user_id
        }
        handle = UserHandle()
        result = handle.reset_password(data)
        print('result', result)
        flash("重置成功", category='message')
        response = json.dumps({'success': True})
        return Response(response, mimetype='application/json')


if __name__ == '__main__':
    app.config.from_object('config')
    app.run()
