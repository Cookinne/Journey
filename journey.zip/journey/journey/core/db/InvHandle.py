#!/usr/bin/env python
# encoding: utf-8
import sqlite3   # 导入模块


class InvHandle(object):

    def __init__(self):
        """
        初始化函数，创建数据库连接
        """
        self.conn = sqlite3.connect('core/db/db.sqlite')
        self.c = self.conn.cursor()

    def inv_add(self, handle_data):
        print('handle_data', handle_data)
        # 向表中插入一条数据
        self.c.execute("insert into invitation (id, title, content, create_time, creator_id) values(?, ?, ?, ?, ?)",\
                       (None, handle_data['title'], handle_data['content'], \
                        handle_data['create_time'], handle_data['creator_id']))

        # 提交当前事务，保存数据
        self.conn.commit()

        # 关闭数据库连接
        self.conn.close()

    def inv_list(self, handle_data):
        print('handle_data', handle_data)
        self.c.execute("select count(*) 'sum' from invitation")
        total = self.c.fetchall()[0][0]
        print('total', total)
        self.c.execute('select * from invitation order by create_time DESC limit ? offset ?', \
                       (handle_data['size'], handle_data['page'] * handle_data['size']))
        db_data = self.c.fetchall()
        # 关闭数据库连接
        self.conn.close()
        return total, db_data

    def inv_detail(self, handle_data):
        print('handle_data', handle_data)
        self.c.execute('select title, content, creator_id, create_time from invitation where id = ?', (handle_data['inv_id'],))
        db_data = self.c.fetchall()
        # 关闭数据库连接
        self.conn.close()
        return db_data

    def inv_delete(self, handle_data):
        print('handle_data', handle_data)
        self.c.execute('delete from invitation where id = ? and creator_id = ?', \
                       (handle_data['inv_id'], handle_data['user_id']))
        # 提交当前事务，保存数据
        self.conn.commit()
        result = self.c.fetchall()
        # 关闭数据库连接
        self.conn.close()
        return result
