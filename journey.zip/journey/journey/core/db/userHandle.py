#!/usr/bin/env python
# encoding: utf-8
import sqlite3   # 导入模块


class UserHandle(object):

    def __init__(self):
        """
        初始化函数，创建数据库连接
        """
        self.conn = sqlite3.connect('core/db/db.sqlite')
        self.c = self.conn.cursor()

    def user_add(self, handle_data):
        # 向表中插入一条数据
        self.c.execute("insert into user (id, name, password) values(?, ?, ?)",\
                       (None, handle_data['name'], handle_data['password']))

        # 提交当前事务，保存数据
        self.conn.commit()

        # 关闭数据库连接
        self.conn.close()

    def get_user(self, handle_data):
        print('handle_data', handle_data)
        self.c.execute('select * from user where name=? and password=?', (handle_data['name'], handle_data['password']))

        data = {
            'success': True,
            'message': '登录成功',
            'data': []
        }
        result = self.c.fetchall()
        print('result', result)
        if len(result) <= 0:
            data['success'] = False
            data['message'] = '登录失败，用户名或密码验证失败'
        elif len(result) > 1:
            data['success'] = False
            data['message'] = '登录失败，用户重复，账号已被锁定'
        else:
            data['data'] = result[0]
        return data

    def reset_password(self, handle_data):
        # 向表中插入一条数据
        self.c.execute("update user set password = ? where id = ?",\
                       (handle_data['password'], handle_data['user_id']))

        # 提交当前事务，保存数据
        self.conn.commit()
        result = self.c.fetchall()

        # 关闭数据库连接
        self.conn.close()

        return result